/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorators;

/**
 *
 * @author fa20-bse-057
 */
public class Example {
    public static void main(String[] args) {
        Order order = new Order() {
            @Override
            public void addItem(Order item) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public double getTotalPrice() {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };

        // Add a Chinese Rice with Chicken and Yogurt
        order.addItem(new ChickenDecorator(new ChineseRice()));
        order.addItem(new YogurtDecorator(new ChineseRice()));

        // Add a Chicken Broast
        order.addItem(new ChickenBroast());

        // Add a Shawarma
        order.addItem(new Shawarma());

        // Add a Salad
        order.addItem(new Salad());

        // Get the total price of the order
        double totalPrice = order.getTotalPrice();

        System.out.println(totalPrice);
    }
}